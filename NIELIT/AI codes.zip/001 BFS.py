def bfs(graph, start):
    visited = []  # To keep track of visited nodes
    queue = [start]  # Initialize queue with the starting node
    
    while queue:
        node = queue.pop(0)  # Dequeue a node
        if node not in visited:
            print(node, end=' ')  # Process the node (print in this case)
            visited.append(node)  # Mark as visited
            
            # Enqueue all adjacent, unvisited nodes
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    queue.append(neighbor)

# Example usage
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F', 'G'],
    'D': ['B'],
    'E': ['B', 'H'],
    'F': ['C'],
    'G': ['C'],
    'H': ['E']
}

print("BFS Traversal starting from node 'A':")
bfs(graph, 'A')
class Node:
    def __init__(self, name, heuristic=0, children=None):
        self.name = name
        self.heuristic = heuristic  # Estimated cost to goal
        self.children = children if children else {}  # {'AND': [(cost, [nodes])], 'OR': [(cost, [nodes])]}

def ao_star(graph, start):
    open_list = {start}  # Nodes to process
    solved = set()  # Solved nodes
    costs = {}  # Best cost storage
    path = {}  # To track optimal path

    # Initialize leaf nodes (goal nodes)
    for node in graph:
        if not graph[node].children:
            costs[node] = graph[node].heuristic
            solved.add(node)

    while open_list:
        node = min(open_list, key=lambda n: costs.get(n, float('inf')))  # Pick node with least cost
        open_list.remove(node)
        best_cost, best_children = float('inf'), None

        for relation, branches in graph[node].children.items():
            for cost, children in branches:
                if all(c in solved for c in children):  # Only consider solved paths
                    total_cost = cost + sum(costs[c] for c in children) + graph[node].heuristic
                    if total_cost < best_cost:
                        best_cost, best_children = total_cost, children

        if best_children:
            costs[node] = best_cost
            solved.add(node)
            path[node] = best_children
            for child in best_children:
                if child not in solved:
                    open_list.add(child)

    return costs, path

def print_optimal_path(start, path):
    print("\nOptimal Path:")
    current = start
    while current in path:
        print(f"{current} -> {path[current]}")
        current = path[current][0]  # Follow best path

# Define a graph with heuristic values and AND-OR conditions
graph = {
    'A': Node('A', heuristic=3, children={'OR': [(1, ['B']), (3, ['C'])], 'AND': [(2, ['D', 'E'])]}),
    'B': Node('B', heuristic=2, children={'OR': [(2, ['F']), (3, ['G'])]}),
    'C': Node('C', heuristic=4, children={'AND': [(4, ['H', 'I'])]}),
    'D': Node('D', heuristic=6),
    'E': Node('E', heuristic=1),
    'F': Node('F', heuristic=2),
    'G': Node('G', heuristic=0),  # Goal node
    'H': Node('H', heuristic=1),
    'I': Node('I', heuristic=0)  # Goal node
}

# Run AO* search
costs, path = ao_star(graph, 'A')

# Print results
print("\nOptimal Costs:")
for node, cost in costs.items():
    print(f"{node}: {cost}")

# Print the optimal path
print_optimal_path('A', path)

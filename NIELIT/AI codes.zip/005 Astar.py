def astar(graph, start, goal, heuristic):
    priority_queue = [(0 + heuristic[start], 0, start, [start])]  # (f = g + h, g, node, path)
    visited = {}
    
    while priority_queue:
        priority_queue.sort()  # Sort manually based on f value
        _, g, node, path = priority_queue.pop(0)  # Get node with lowest f value
        
        if node in visited and visited[node] <= g:
            continue  # Skip if already visited with a lower or equal cost
        
        visited[node] = g  # Mark as visited with cost
        print(f"Visited {node} with cost {g}")
        
        if node == goal:
            print(f"Reached goal {goal} with cost {g}")
            print("Path:", " -> ".join(path))
            return
        
        for neighbor, weight in graph.get(node, []):
            if neighbor not in visited or g + weight < visited[neighbor]:
                f = g + weight + heuristic[neighbor]  # Calculate f = g + h
                priority_queue.append((f, g + weight, neighbor, path + [neighbor]))

# Example usage
graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('D', 2), ('E', 5)],
    'C': [('A', 4), ('F', 3)],
    'D': [('B', 2)],
    'E': [('B', 5), ('H', 1)],
    'F': [('C', 3)],
    'H': [('E', 1)]
}

heuristic = {
    'A': 7, 'B': 6, 'C': 2, 'D': 4, 'E': 3, 'F': 1, 'H': 0
}

print("A* Search from A to H:")
astar(graph, 'A', 'H', heuristic)

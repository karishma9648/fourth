def ucs(graph, start, goal):
    priority_queue = [(0, start, [start])]  # (cost, node, path)
    visited = {}
    
    while priority_queue:
        priority_queue.sort()  # Sort manually to get the lowest cost node
        cost, node, path = priority_queue.pop(0)  # Get node with lowest cost
        
        if node in visited and visited[node] <= cost:
            continue  # Skip if already visited with a lower cost
        
        visited[node] = cost  # Mark as visited with cost
        print(f"Visited {node} with cost {cost}")
        
        if node == goal:
            print(f"Reached goal {goal} with cost {cost}")
            print("Path:", " -> ".join(path))
            return
        
        for neighbor, weight in graph.get(node, []):
            if neighbor not in visited or cost + weight < visited[neighbor]:
                priority_queue.append((cost + weight, neighbor, path + [neighbor]))

# Example usage
graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('D', 2), ('E', 5)],
    'C': [('A', 4), ('F', 3)],
    'D': [('B', 2)],
    'E': [('B', 5), ('H', 1)],
    'F': [('C', 3)],
    'H': [('E', 1)]
}

print("Uniform Cost Search (UCS) from A to H:")
ucs(graph, 'A', 'H')

def dfs(graph, start, visited=None):
    if visited is None:
        visited = []  # To keep track of visited nodes
    
    if start not in visited:
        print(start, end=' ')  # Process the node (print in this case)
        visited.append(start)  # Mark as visited
        
        # Recursively visit all adjacent, unvisited nodes
        for neighbor in graph.get(start, []):
            dfs(graph, neighbor, visited)

# Example usage
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F', 'G'],
    'D': ['B'],
    'E': ['B', 'H'],
    'F': ['C'],
    'G': ['C'],
    'H': ['E']
}

print("DFS Traversal starting from node 'A':")
dfs(graph, 'A')
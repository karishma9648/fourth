def gbfs(graph, start, goal, heuristic):
    priority_queue = [(heuristic[start], start, [start])]  # (heuristic value, node, path)
    visited = set()
    
    while priority_queue:
        priority_queue.sort()  # Sort manually based on heuristic value
        _, node, path = priority_queue.pop(0)  # Get node with lowest heuristic value
        
        if node in visited:
            continue  # Skip if already visited
        
        visited.add(node)  # Mark as visited
        print(f"Visited {node}")
        
        if node == goal:
            print(f"Reached goal {goal}")
            print("Path:", " -> ".join(path))
            return
        
        for neighbor, _ in graph.get(node, []):
            if neighbor not in visited:
                priority_queue.append((heuristic[neighbor], neighbor, path + [neighbor]))

# Example usage
graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('D', 2), ('E', 5)],
    'C': [('A', 4), ('F', 3)],
    'D': [('B', 2)],
    'E': [('B', 5), ('H', 1)],
    'F': [('C', 3)],
    'H': [('E', 1)]
}

heuristic = {
    'A': 7, 'B': 6, 'C': 2, 'D': 4, 'E': 3, 'F': 1, 'H': 0
}

print("Greedy Best-First Search (GBFS) from A to H:")
gbfs(graph, 'A', 'H', heuristic)
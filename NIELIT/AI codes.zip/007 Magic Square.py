def generate_magic_square(n):
    if n % 2 == 0:
        raise ValueError("Only odd-order magic squares can be generated using this method.")

    magic_square = [[0] * n for _ in range(n)]

    # Start from the middle of the first row
    i, j = 0, n // 2

    for num in range(1, n * n + 1):
        magic_square[i][j] = num
        
        # Store the previous position
        prev_i, prev_j = i, j

        # Move up and right
        i -= 1
        j += 1

        # Wrap around
        if i < 0:
            i = n - 1  # Wrap row
        if j >= n:
            j = 0  # Wrap column

        # If the new position is already filled, move down instead
        if magic_square[i][j] != 0:
            i = prev_i + 1
            j = prev_j

    return magic_square

def print_magic_square(square):
    for row in square:
        print(" ".join(f"{num:2}" for num in row))

# Example: Generate a 3x3 magic square  
n = 5
magic_square = generate_magic_square(n)
print_magic_square(magic_square)